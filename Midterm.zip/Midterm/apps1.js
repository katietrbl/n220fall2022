//create the div and add dimensions and link it to the inner html so it will display the "div"
let aDiv = document.getElementById("Div");

    aDiv.innerHTML = "100";

function addDiv(){
    //subtracts five 
    aDiv.innerHTML = 100 - 5;
    aDiv.append;
}